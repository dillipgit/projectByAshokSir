package com.dilu.assign;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class FindDuplicate_In_Array {

	public static void main(String[] args) {
		
		int[] input = {1, 2, 5, 5, 6, 6, 7, 2};
		
		List<Integer> numbers = Arrays.asList(new Integer[]{1, 2, 5, 5, 6, 6, 7, 2});  
		
		int len = input.length;
		System.out.println("Duplicate elements in given array:: "); 
		for(int x=0;x <len;x++) {
			for(int y=x+1;y <len;y++) {
				if(input[x] == input[y]) {
					System.out.println(input[x]);
				}
			}
		}
		
	
		System.out.println("=====USING JAVA 8 FEATURE=====");		
		numbers.stream()
		                 .filter(i -> Collections.frequency(numbers, i) > 1)
		                 .collect(Collectors.toSet())
		                 .forEach(System.out::println);
		
		

		
	}

}
