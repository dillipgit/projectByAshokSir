package com.dilu.assign;

import java.util.Arrays;

public class Find_2ndmin_2ndMax {

	public static void main(String[] args) {
		
		int[] input = { 1, 2, 5, 9, 6, 4, 7, 2};
		Arrays.sort(input);
		int length = input.length-1;
		
		System.out.println("second min no is: "+input[1]+" second max no is: "+input[length-1]);
		
		

	}

}
