package com.dilu.assign;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Sum_UniqueElements_Array {
	
	public static void main(String[] args) {
		
		int[] input = {1, 6, 4, 3, 2, 2, 3, 8, 1};
		Set<Integer> store = new HashSet<>();
		int sum = 0;
		
		for(int x:input) {
			store.add(x);
		}
		for(int x:store) {
			sum = sum+x;
		}
		System.out.println(sum);
		
		
		//USING JAVA 8 FEATURE
		System.out.println("========================");
		int output = Arrays.stream(input).distinct().sum();
		System.out.println(output);
	}

}
