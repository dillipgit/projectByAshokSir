package com.dilu.assign;

import java.util.Set;
import java.util.TreeSet;

public class Third_Largest_InArray {
	
	public static void main(String[] args) {
		
		int[] input = { 6, 8, 1, 9, 2, 1, 10, 12};
		 Set<Integer> output = new TreeSet<>();
		 for(int x:input) {
			 output.add(x);
		 }
		Object[]  result = output.toArray();
		System.out.println(result[3]);
		
		//USING JAVA 8 FEATURE
	System.out.println("==================");
		
		
	
		 
	}

}
