package com.dilu.assign;

import java.util.Arrays;

public class FindTheMaximumDistance {
	
	public static void main(String[] args) {
		int[] input = {9, 2, 12, 5, 4, 7, 3, 19, 5};
		int size=input.length-1;
		int distance = 0;
		Arrays.sort(input);
		
		distance=input[size] - input[0];
		System.out.println(distance);
		
	}

}
