package com.dilu.assign;

import java.util.ArrayList;

public class FindCommonElement {

	public static void main(String[] args) {
		
		int ar1[] = {1, 5, 10, 20, 40, 80};
		int ar2[] = {6, 7, 20, 80, 100};
		int ar3[] = {3, 4, 15, 20, 30, 70, 80, 120};
		
		ArrayList<Integer> common = new ArrayList<Integer>();
		  
			int x = 0, y = 0, z = 0;
			while (x < ar1.length && y < ar2.length && z < ar3.length){
				if (ar1[x] == ar2[y] && ar2[y] == ar3[z]){
					common.add(ar1[x]);
					x++;
					y++;
					z++;
				}
				else if (ar1[x] < ar2[y])
					x++;
				else if (ar2[y] < ar3[z])
					y++;
				else
					z++;
			}
			System.out.println("Common elements from three arrays:  "+common);
		
		}

}
