package com.dilu.assign;

import java.util.Arrays;

public class Find_Min_Max {

	public static void main(String[] args) {
		
		int[] input = { 1, 2, 5, 5, 6, 6, 7, 2};
		int length = input.length-1;
		 Arrays.sort(input);
		 
		 System.out.println("min no is: "+input[0]+" max no is:"+input[length]);
//using java 8 feature
		 System.out.println("==========================");
		System.out.println( Arrays.stream(input).max());
		System.out.println( Arrays.stream(input).min());
	}

}
