package com.dilu.assign;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicate_Array {
	
	
	public static void main(String[] args) {
		
		int[] input = {1, 2, 5, 5, 6, 6, 7, 2};
		
		List<Integer> list = new ArrayList<>();
		for(int x:input) {
			list.add(x);
		}
		
		//logic
		Set<Integer> output = new HashSet<>();
		for(int x:input) {
			output.add(x);
		}
		System.out.println(output);
		
		
		System.out.println("=====USING JAVA 8 FEATURE========");
		list.stream().distinct().forEach(System.out::println);
		
		System.out.println("==================");
		Arrays.stream(input).distinct().forEach(System.out::println);
		
	
		
		
	}

}
